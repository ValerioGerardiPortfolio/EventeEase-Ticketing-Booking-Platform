const path    = require('path');
const sqlite3 = require('sqlite3').verbose();

const filename = path.join(__dirname, '../eventease.db');

const db = new sqlite3.Database(
  filename,
  sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE,
  err => {
    if (err) {
      console.error('Could not open DB at', filename, err);
      process.exit(1);
    }
    console.log('Database opened at', filename);
  }
);

module.exports = db;


