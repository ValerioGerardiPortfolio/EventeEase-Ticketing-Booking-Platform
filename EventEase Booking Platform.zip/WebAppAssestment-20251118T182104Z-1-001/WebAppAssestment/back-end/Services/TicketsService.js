const TicketsDAO = require('../DAOs/TicketsDAO');

class TicketsService{
    constructor(){
        this.ticketsDao = new TicketsDAO();
    }
    //create new ticket
        
    async create(req) {
        const result = await this.ticketsDao.create(req);
        if (!result.success) {
            console.error(result.error);
            return result;
        }
        return result;
    }

        
    //retrievess all tickets
    async retrieveAll(){
        const result = await this.ticketsDao.retrieveAll();
        if(!result.succes){
            return result;
        }
        
            return result;
    }
    //retrieve tickets by ID
    async retrieveById (){
        const result = await this.ticketsDao.retrieveByID();
        if(!result.succes){
            return result;
        }
        
            return result;
    }
    // Retrieve tickets of a event by name
    async retrieveByEventName(req) {
        const result = await this.ticketsDao.retrieveByEventName(req);
        if (!result.success) {
            return result;
        }
        return result;
    }

    //updates tickets
    async update(req){
        const result = await this.ticketsDao.update(req);
        if(!result.succes){
            console.error(result.error);
            return result;
        }
        return result;
    }
    //delete tickets
    async delete(req){
        const result = await this.ticketsDao.delete(req);
        if(!result.succes){
            console.error(result.error);
            return result;
        }
            return result;
    }
    
}

module.exports = TicketsService;