const EventsDAO = require('../DAOs/EventsDAO');

class EventService{
    constructor(){
        this.eventsDao = new EventsDAO();
    }
    //new event creation
    async create(req){
        const result = await this.eventsDao.create(req)
        if(!result.success){
            console.error(result.error)
                return result;
        }
        
        return result;
    }

        
    //retrieve all events avilable
    async retrieveAll(){
        const result = await this.eventsDao.retrieveAll()
        if(!result.succes){
            return result;
        }
        return result;
        }

    //retrieve events by id
    async retrieveByID(req){
        const result = await this.eventsDao.retrieveByID(req);
        if(!result.succes){
            return result;
        }
        return result;
    }
    //retrieve events by location
    async retrieveByLocation(req){
        const result = await this.eventsDao.retrieveByLocation(req);
        if(!result.succes){
            return result;
        }
        return result;
    }
    //updates an events
    async update(req){
        const result = await this.eventsDao.update(req);
        if(!result.succes){
            console.error(result.error);
            return result;
        }
       
         return result;
        }
    //delete an event
    async delete(req){
        const result = await this.locationDao.delete(req);
        if(!result.succes){
            console.error(result.error);
            return result;
        }
        
        return result;
        }
    }


module.exports = EventService;