const BookingsDAO = require ('../DAOs/BookingsDAO');



class BookingsService{
    constructor(){
        this.bookingsDao = new BookingsDAO();
    }
    //create a new booking
    async create(req){
        const result = await this.bookingsDao.create(req);
        if (!result.success) {
            return result;
        }
        return result;
    }

    //book a ticket for an event
    async EventBooking(req){
        const result= await this.bookingsDao.EventBooking(req);
        if(!result.success){
            return result;
        }
        return result;
    }
    //retrieve bookings by id
    async retrieveByID(req){
        const result = await this.bookingsDao.retrieveByID(req);
        if(!result.succes){
            return result;
        }
        return result;
    }

        
    //retrieve all bookings
    async retrieveAll(){
        const result = await this.bookingsDao.retrieveAll()
        if(!result.succes){
            return result;
        }
        
        return result;
    }

    //updates a booking
    async update(req){
        const result = await this.bookingsDao.update(req)
        if(!result.success)
            return result;
        
        {
        return result;
        }
    }
    //deletes a booking
    async delete(req){
        const result = await this.bookingsDao.delete(req)
        if(!result.succes)
            return result;
        
        {
        return result;
        }
    }
}

module.exports = BookingsService;