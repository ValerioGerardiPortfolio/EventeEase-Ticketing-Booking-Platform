const UsersDAO = require('../DAOs/UsersDAO');
const{ hashpassword, verifyPassword} = require('../Utilities/bcryptUtility')


class UsersService{
    constructor(){
        this.usersDao = new UsersDAO();
    }
    //create e new user
    async create(req){
        req.body.password = await hashpassword(req.body.password);
        console.log(req.body.password);
        const result = await this.usersDao.create(req);
        if(!result.success){
            console.error(result.error);
                return this.usersDao.create(req);
        }
        return result;
    }
    //retrieve all users
    async retrieveAll(){
        const result = await this.usersDao.retrieveAll();
        if(!result.succes){
            return result;
        }
        return result;
    }

    //retrieve by username
       async login(req){
        const result  = await this.usersDao.retrieveByUsername(req)
        console.log(req.body.password)
        console.log(result)
        const isMatch = await verifyPassword(req.body.password, result.result.password)
        if(isMatch)
        {
            req.session.user ={
                username:req.body.username
            }
            req.session.isAuthenticated = true
            //console.log("It matches") //left here only for testing purposes
        }
        else{
            console.log("It doesn not match")
        }
        result.success = isMatch
        return result
    }

    //updates a user
    async update(req){
        const result = await this.usersDao.update(req);
        if(!result.succes){
            console.error(result.error);
            return result;
        }
        return result
    }
    //delete a user
    async delete(req){
        const result = await this.usersDao.delete(req);
        if(!result.succes){
            console.error(result.error);
            return result;
        }
        return result;
    }
}


module.exports = UsersService;