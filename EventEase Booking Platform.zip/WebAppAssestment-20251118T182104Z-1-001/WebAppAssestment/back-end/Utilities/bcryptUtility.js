const bcrypt = require('bcrypt');

const hashpassword = async(plain_password) =>{
    const saltRounds = 10;
    const extrasalt = await bcrypt.genSalt(saltRounds)//Salting the password adding an extra random string
    const finalhashedpassword = await bcrypt.hash(plain_password, extrasalt)
    return finalhashedpassword
}

const verifyPassword = async (passwordFromUser, passwordFromDb) =>{
    try{
        const isMatch = await bcrypt.compare(passwordFromUser, passwordFromDb)
        return isMatch
    }
    catch(ex){
        console.error(ex)//Never leave this in production 
    }
}

module.exports = {hashpassword, verifyPassword};