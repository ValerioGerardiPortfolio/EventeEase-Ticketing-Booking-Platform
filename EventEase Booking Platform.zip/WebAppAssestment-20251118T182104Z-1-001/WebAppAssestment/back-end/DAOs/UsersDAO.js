const connection = require('../DBConnection/DBCon');
const createResponse = require('../Utilities/CreateResponse');



class UsersDAO{
    constructor(){}


    
    //new user creation
    async create(req) {
        return new Promise((resolve, reject) => {
            connection.run('INSERT INTO users (username, password, isAdmin) VALUES (?,?,?)', 
                [req.body.username, req.body.password, req.body.isAdmin], 
                (err, result) => {
                    if (err) {
                        reject(createResponse(false, 'Error in db', err))
                    }
                    resolve(createResponse(true, result))
                })
        })
    }
        
    
    //retrieve all users
    async retrieveAll() {
        return new Promise((resolve, reject) => {
            connection.all('SELECT * FROM users', [], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err))
                }
                resolve(createResponse(true, result))
            })
        })
    }
    //retrieve user by single id
    async retrieveById(req) {
        return new Promise((resolve, reject) => {
            connection.get('SELECT * FROM users WHERE id = (?)', [req.body.id], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err))
                }
                resolve(createResponse(true, result))
            })
        })
    }
    //retrieve user by username. Needed for login
    async retrieveByUsername(req){
        return new Promise((resolve, reject) =>{
            connection.get('Select password from users where username = (?)', [req.body.username], (err, result) =>{
                if(err){
                    reject(createResponse(false , 'DB Error', err))
                }
                resolve(createResponse(true, result))
            })
        })
        }
    //update user info
    async update(req) {
        return new Promise((resolve, reject) => {
            connection.run('UPDATE users SET username = ?, password = ?, isAdmin = ? WHERE id = ?', 
                [req.body.username, req.body.password, req.body.isAdmin, req.body.id], 
                (err, result) => {
                    if (err) {
                        reject(createResponse(false, 'Error in db', err))
                    }
                    resolve(createResponse(true, result));
                });
        });
    };
    //delete user
    async delete(req) {
        return new Promise((resolve, reject) => {
            connection.run('DELETE FROM users WHERE id = (?)', [req.body.id], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err))
                }
                resolve(createResponse(true, result))
            })
        })
    }
}

   
module.exports = UsersDAO;