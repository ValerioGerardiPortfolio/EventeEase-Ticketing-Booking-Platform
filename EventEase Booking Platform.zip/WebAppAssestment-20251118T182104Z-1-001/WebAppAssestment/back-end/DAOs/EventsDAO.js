
const connection = require('../DBConnection/DBCon');
const createResponse = require('../Utilities/CreateResponse');

class EventsDAO{
    constructor(){

    }
    //creates a new event
    async create(req) {
        return new Promise((resolve, reject) => {
            connection.run('INSERT INTO events (name, category, location, date, lon, lat, description) VALUES (?, ?, ?, ?, ?, ?, ?)', 
            [
                req.body.name,
                req.body.category,
                req.body.location,
                req.body.date,
                req.body.lon,
                req.body.lat,
                req.body.description
            ], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, 'Event created', { id: this.lastID }));
            });
        });
    }
    //retrieves events by single location
    async retrieveByLocation(location) {
        return new Promise((resolve, reject) => {
            connection.all('SELECT * FROM events WHERE location = ?', [location], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, result));
            });
        });
    }
    //retrieves all events
    async retrieveAll() {
        return new Promise((resolve, reject) => {
            connection.all('SELECT * FROM events', [], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, result));
            });
        });
    }
    //retrieves all events by id
    async retrieveById(req) {
        return new Promise((resolve, reject) => {
            connection.get('SELECT * FROM events WHERE id = ?', [req.body.id], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, result));
            });
        });
    }
    //event update
    async update(req) {
        return new Promise((resolve, reject) => {
            connection.run('UPDATE events SET name = ?, category = ?, location = ?, date = ?, lon = ?, lat = ?, description = ? WHERE id = ?',
            [
                req.body.name,
                req.body.category,
                req.body.location,
                req.body.date,
                req.body.lon,
                req.body.lat,
                req.body.description,
                req.body.id
            ], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, 'Event updated'));
            });
        });
    }
    async delete(req) {
        return new Promise((resolve, reject) => {
            connection.run('DELETE FROM events WHERE id = ?', [req.body.id], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, 'Event deleted'));
            });
        });
    }
}

   
module.exports = EventsDAO;