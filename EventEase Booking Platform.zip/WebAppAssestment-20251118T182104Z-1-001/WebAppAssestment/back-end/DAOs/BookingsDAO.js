const connection = require('../DBConnection/DBCon');
const createResponse = require('../Utilities/CreateResponse');



class BookingsDAO{
    constructor(){} 
    async create(req) {
        return new Promise((resolve, reject) => {
            connection.run('INSERT INTO bookings (eventID, ticketType, username, quantity) VALUES (?, ?, ?, ?)', 
            [   req.body.eventID,
                req.body.ticketType,
                req.body.username,
                req.body.quantity
            ], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, 'Booking created', { id: this.lastID }));
            });
        });

    }
    
async EventBooking(req) {
    const { eventID, ticketType, username, quantity } = req.body;

    return new Promise((resolve, reject) => {
      // Get the event date and  availability 
      connection.get(`SELECT e.date   AS eventDate,t.availability FROM tickets t JOIN events  e ON t.eventID = e.id WHERE t.eventID = ? AND t.ticketType = ?`,
        [eventID, ticketType],
            (err, row) => {
              if (err) {
              //  DB error
                  return reject({
                      success: false,
                      message: 'Database error',
                      result: { error: err.message }});
                    }
              if (!row) {
               // Message for no tickets found
                  return resolve({
                      success: false,
                      message: 'Event or ticket not found'});}

    const raw = row.eventDate; 
            if (typeof raw !== 'string' || raw.length !== 6) {
                  return resolve({
                      success: false,
                      message: 'Invalid date format',
                      result: { eventDate: raw }});
                    }

          //  Parse date in a readable date
    const yy    = 2000 + parseInt(raw.slice(0, 2), 10);
    const mm    = parseInt(raw.slice(2, 4), 10) - 1; 
    const dd    = parseInt(raw.slice(4, 6), 10);
    const date  = new Date(yy, mm, dd);

          if (isNaN(date.getTime())) {
                  return resolve({
                      success: false,
                      message: 'Invalid event date',
                      result: { eventDate: raw }});
                    }

    const today = new Date();
      today.setHours(0, 0, 0, 0);
          if (date < today) {
                    return resolve({
                      success: false,
                      message: 'Cannot book past events',
                      result: { eventDate: raw }});
                    }

          // Check availability
          if (row.availability < quantity) {
                    return resolve({
                      success: false,
                      message: 'Not enough tickets available',
                      result: {
                      eventDate: raw,
                      availability: row.availability}});
                    }

          // insert booking, then decrement availability
      connection.run(`INSERT INTO bookings (eventID, ticketType, username, quantity)VALUES (?, ?, ?, ?)`,
        [eventID, ticketType, username, quantity],
            function (err2) {
          if (err2) {
                    return reject({
                      success: false,
                      message: 'Database error creating booking',
                      result: { error: err2.message }});
                    }
                    const bookingId = this.lastID;

      connection.run(`UPDATE ticketsSET availability = availability - ? WHERE eventID = ? AND ticketType = ?`,
        [quantity, eventID, ticketType],
              (err3) => {
          if (err3) {
                    return reject({
                      success: false,
                      message: 'Database error updating availability',
                      result: { error: err3.message }});
                    }

                  // Success: return bookingId  and the raw eventDate
                    resolve({
                      success: true,
                      message: 'Booking confirmed',
                      result: {
                      bookingId,
                      eventDate: raw
                    }
                  });
                }
              );
            }
          );
        }
      );
    });
  }
   // Retrieve all bookings
    async retrieveAll() {
        return new Promise((resolve, reject) => {
            connection.all('SELECT * FROM bookings', [], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, result));
            });
        });
    }
    
    
    //retrieve bookings by single ID
    async retrieveById(req) {
        return new Promise((resolve, reject) => {
            connection.get('SELECT * FROM bookings WHERE id = ?', [req.body.id], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, result));
            });
        });
    }
    //booking update
       async update(req) {
        return new Promise((resolve, reject) => {
            connection.run('UPDATE bookings SET eventID = ?, ticketType = ?, username = ?, quantity = ? WHERE id = ?',
            [
                req.body.eventID,
                req.body.ticketType,
                req.body.username,
                req.body.quantity,
                req.body.id
            ], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, 'Booking updated'));
            });
        });
    }

        // Delete a booking
    async delete(req) {
        return new Promise((resolve, reject) => {
            connection.run('DELETE FROM bookings WHERE id = ?', [req.body.id], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, 'Booking deleted'));
            });
        });
    }


async getEventDetails(eventID, ticketType) {                        
  return new Promise((resolve, reject) => {
        connection.get(
        `SELECT e.date AS eventDate, t.availability AS availability
        FROM tickets t
        JOIN events e ON t.eventID = e.id
        WHERE t.eventID = ? AND t.ticketType = ?`,
                [eventID, ticketType],
                    (err, row) => {
                if (err) {
                    return resolve({ success: false, message: 'Database error', error: err });
                    }
                if (!row) {
                    return resolve({ success: false, message: 'Event or ticket not found' });
                    }
                    resolve({ success: true, result: row });

                }
            );
        });
    }
}


   
module.exports = BookingsDAO;