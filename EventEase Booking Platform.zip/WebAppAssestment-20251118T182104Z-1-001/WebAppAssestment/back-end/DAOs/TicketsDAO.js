const connection = require('../DBConnection/DBCon')
const createResponse = require('../Utilities/CreateResponse')


class TicketsDAO{
    constructor(){

    }
        // Create a new ticket
    async create(req) {
        return new Promise((resolve, reject) => {
            connection.run('INSERT INTO tickets (eventID, ticketType, price, availability) VALUES (?, ?, ?, ?)', 
            [
                req.body.eventID,
                req.body.ticketType,
                req.body.price,
                req.body.availability
            ], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'DB error', err));
                }
                resolve(createResponse(true, 'Ticket created', { id: this.lastID }));
            });
        });
    }
    //retrieve all tickets 
    async retrieveAll() {
        return new Promise((resolve, reject) => {
            connection.all('SELECT * FROM tickets', [], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, result));
            });
        });
    }
    //retrieve events by single id
    async retrieveById(req) {
        return new Promise((resolve, reject) => {
            connection.get('SELECT * FROM tickets WHERE id = ?', [req.body.id], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, result));
            });
        });
    }
    async retrieveByEventName(name) {
        return new Promise((resolve, reject) => {
            connection.all(
                `SELECT availability, price FROM tickets t 
                JOIN events e ON t.eventID = e.id 
                WHERE e.location = ? and availability > 0`, [name], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'DB error', err));
                }
                resolve(createResponse(true,  'not enough tickets',result));
            });
        });
    }

    //update tickets
    async update(req) {
        return new Promise((resolve, reject) => {
            connection.run('UPDATE tickets SET eventID = ?, ticketType = ?, price = ?, availability = ? WHERE id = ?',
            [
                req.body.eventID,
                req.body.ticketType,
                req.body.price,
                req.body.availability,
                req.body.id
            ], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, 'Ticket updated'));
            });
        });
    }
      // Delete a ticket
    async delete(req) {
        return new Promise((resolve, reject) => {
            connection.run('DELETE FROM tickets WHERE id = ?', [req.body.id], (err, result) => {
                if (err) {
                    reject(createResponse(false, 'Error in db', err));
                }
                resolve(createResponse(true, 'Ticket deleted'));
            });
        });
    }
}

   
module.exports = TicketsDAO;