const express = require('express');
const router = express.Router();
const EventService = require('../Services/EventService');
const path = require('path');

const eventService = new EventService();

//route to create new event
router.post('/create', async (req,res) => {
    try{
        const result = await eventService.create(req);
        return res.status(201).json(result); 
    }catch(error){
        console.error('post request failed', error);
        res.status(500).json({error:'there is an error in creating your event'});
    }
});


//Finds the main page to create a event
router.get('/getAllPage', async(req,res)=>{
    res.sendFile(path.join(__dirname,'..','Views', 'AllEvents.html'));
});


//Route to retrieve all events
router.get('/getAll', async(req,res)=>{
    try{
        const result = await eventService.retrieveAll();
        res.json(result.result);
    }catch(error){
        res.status(500).json({error:'there is an error in finding bookings'});

    }
});

//Finds an event by location
router.get('/:location', async(req,res)=>{
    try{
        const location = req.params.location;   
        const result = await eventService.retrieveByLocation(location);
        res.json(result.result); 

    }catch(error){
        res.status(500).json({error:'There is an error while finding events by location'});

    }

});


router.get('/:events', async (req, res) => {
    try {
        const name = req.params.name;
        const result = await ticketsService.retrieveByEventName(name);
        res.json(result.result); 
    } catch (error) {
        console.error("Error in /tickets/:event", error);
        res.status(500).json({ error: 'There is an error while finding tickets' });
    }
});



module.exports = router;