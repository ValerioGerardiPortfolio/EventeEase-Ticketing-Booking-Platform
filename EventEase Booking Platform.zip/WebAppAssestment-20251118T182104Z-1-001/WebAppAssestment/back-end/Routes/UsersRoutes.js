const express = require('express');
const router = express.Router();
const UsersService = require('../Services/UsersService');
const path = require('path');


const userService = new UsersService();

router.post('/create', async(req, res) => {
    try{

        const result = await userService.create(req);
        return res.status(201).json(result);
        //res.json(result);
    }catch (error){
        console.error('create/users/failed', error);
        return res.status(500).json({error:'There is an error on creating the user'});
    }
});
//finds the user creation page
router.get('/getAllPage', async(req,res)=>{
        res.sendFile(path.join(__dirname,'..','Views','Users.html'));
});

//route to get all users
router.get('/getAll', async(req,res)=>{
    try{const result = await userService.retrieveAll();
        res.json(result.result);
    }catch (error){
        res.status(500).json({error:'There is a problem while retrieving users'});

    }
});

//login route
router.post('/login', async (req, res) => {
  const result = await userService.login(req);

  if (result.success) {
    req.session.username = req.body.username; // It saves into the session
    req.session.isAuthenticated = true;
    res.json({ success: true, username: req.body.username });
  } else {
    res.status(401).json({ success: false, message: 'Invalid login' });
  }
});


//logout route
router.post('/logout', (req,res)=>{
  req.session.destroy((err)=>{
    if(err){
      console.error('Failed to logout', err);
      console.res.status(500).json({success:false,message:'Logout failed'});
    }
    res.clearCookie('connect.sid');
    res.json({success:true, message:'Successfully logged out'});
  });
});



// session check route
router.get('/check', (req, res) => {
  if (req.session && req.session.username) {
    return res.json({ success: true, username: req.session.username });
  } else {
    return res.json({ success: false });
  }
});


module.exports = router;