const express = require('express');
const router = express.Router();
const TicketsService = require('../Services/TicketsService')
const path = require('path');

const ticketsService = new TicketsService(); 


// Create a new ticket
router.post('/create', async (req, res) => {
    try {
        const result = await ticketsService.create(req);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: 'An error occurred while creating the ticket.' });
    }
});
// 1. Route to serve the ticket creation page (static file)
router.get('/getAllPage', async (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'Views', 'BookTickets.html'));
});

// 2. Route to retrieve all tickets
router.get('/getAll', async (req, res) => {
    try {
        const result = await ticketsService.retrieveAll();
        res.json(result.result);
    } catch (error) {
        res.status(500).json({ error: 'There is an error in finding tickets' });
    }
});

// 4. Route to retrieve tickets by event name 
router.get('/:event', async (req, res) => {
    try {
        const event = req.params.event;
        
        const result = await ticketsService.retrieveByEventName(event);
        res.json(result.result); 
    } catch (error) {

        res.status(500).json({ error: 'There is an error while finding tickets' });
    }
});

module.exports = router;