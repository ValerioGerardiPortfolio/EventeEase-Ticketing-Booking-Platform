const express = require('express');
const router = express.Router();
const BookingService = require('../Services/BookingsService');
const path = require('path');

const bookingService = new BookingService();

//route to create new booking
router.post('/create', async (req,res) =>{
    try{
        const result = await bookingService.create(req);
        res.json(result); 
    }catch(error){
        res.status(500).json({error:'There is an error on creating your booking'});
    }
});


router.post('/booktickets', async (req, res) => {
    const { eventID, ticketType, username, quantity } = req.body;

    // Input validation
    if (!eventID || !ticketType || !username || !quantity) {
        return res.status(400).json({
            success: false,
            message: 'Missing booking details'
        });
    }

    try {
        
        const result = await bookingService.EventBooking(req);

        if (!result.success) {
            
            return res.status(400).json(result);
        }

        // success path:
        return res.json(result);
    } catch (err) {
        // If something unexpected happens
        return res.status(500).json({ error: 'Tickets are sold out or not enough available})'})
        
    
    }
});


module.exports = router;