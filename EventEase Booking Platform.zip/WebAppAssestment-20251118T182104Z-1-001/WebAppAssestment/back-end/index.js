const express = require('express');
const cors = require('cors');
const session = require('express-session')
const app = express();
const UserRouter = require('./Routes/UsersRoutes');
const BookingsRouter = require('./Routes/BookingsRoutes');
const TicketsRouter =  require('./Routes/TicketsRoutes');
const EventRouter = require('./Routes/EventRoutes');
const sessionAuth = require('./Middleware/SessionAuth');
const PORT = 3000;


app.use(cors({
    origin :'http://localhost:5173', //it allows cross origin sharing from server 5173
    credentials:true
}));


app.use(session({
    secret: 'my_secret_',
    resave:false,
    saveUninitialized: false,
    cookie:{
        secure:false, //https only or http and https
        httpOnly:true,
        maxAge: 24*60*60*1000
    }
}))

app.use(express.json());

//user routes
app.use('/users', UserRouter);

//booking routes
app.use('/booktickets',BookingsRouter);

//tickets routes
app.use('/tickets',TicketsRouter);

//events routes
app.use('/events',sessionAuth, EventRouter);


//this is the port where the server listens to
app.listen(PORT, ()=>{
    console.log(`Listening on port : ${PORT}`)
});