import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
       '/booktickets': {
        target: 'http://localhost:3000',
        changeOrigin: true,
      },
      // Any request starting with /events 
      '/event': {
        target: 'http://localhost:3000',
        changeOrigin: true,
      },
      // Login, logout
      '/users': {
        target: 'http://localhost:3000',
        changeOrigin: true,
      },
      '/tickets': {
        target: 'http://localhost:3000',
        changeOrigin: true,
      },
    }
    
  }
});
