import React, { useState } from 'react';
import Event from './components/Event.jsx';
import OpenStreet from './components/OpenStreet.jsx';
import SearchEvent from './components/SearchEvent.jsx';
import Login from './components/Login.jsx';
import './App.css';

function App() {
  const [events, setEvents] = useState([]);
  const [username, setUsername] = useState(null);

  return (
    <div className="app">
      <h1>EventEase Booking System</h1>

      {/* Login section is shown first */}
      <Login
        onLogin={(user) => setUsername(user)}
        onLogout={() => {
          setUsername(null);
          setEvents([]); // Clears event state on logout
        }}
        username={username}
      />

      {/* Show event if user is logged in */}
      {username ? (
        <>
          <SearchEvent onResults={setEvents} />

          {/* Show map and event if events are found */}
          {events.length > 0 && (
            <>
              
              <Event events={events} username={username} />
            </>
          )}
        </>
      ) : (
        <p>Login and find your favourite event!</p>
      )}
    </div>
  );
}

export default App;

