import React, { useState, useEffect } from 'react';


function Login({ onLogin, onLogout, username }) {
  const [inputUser, setInputUser] = useState('');
  const [inputPass, setInputPass] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    // Checks if user is already logged in
    fetch('/users/check', { credentials: 'include' })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.username) {
          onLogin(data.username);
        }
      });
  }, []);

  const handleLogin = async () => {
    try {
      const res = await fetch('/users/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username: inputUser, password: inputPass })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        onLogin(data.username);
        setInputUser('');
        setInputPass('');
        setError('');
      } else {
        setError(data.message || 'Login failed.');
      }
    } catch (err) {
      setError('Server error');
    }
  };

  const handleLogout = async () => {
    await fetch('/users/logout', {
      method: 'POST',
      credentials: 'include'
    });
    onLogout();
  };

  if (username) {
    return (
      <div className="login-info">
        <p>Welcome back <strong>{username}</strong></p>
        <button onClick={handleLogout}>Logout</button>
      </div>
    );
  }

  return (
    <div className="login-form">
  <div className="form-group">
    <label htmlFor="username">Username:</label>
    <input
      id="username"
      type="text"
      placeholder=""
      value={inputUser}
      onChange={(e) => setInputUser(e.target.value)}
    />
  </div>

  <div className="form-group">
    <label htmlFor="password">Password:</label>
    <input
      id="password"
      type="password"
      placeholder=""
      value={inputPass}
      onChange={(e) => setInputPass(e.target.value)}
    />
  </div>

  <button onClick={handleLogin}>Login</button>
  {error && <p className="error">{error}</p>}
</div>
  );
}

export default Login;