import React, { useState } from 'react';

function SearchEvent({ onResults }) {
  const [location, setLocation] = useState('');
  const [error, setError] = useState(null);

  const handleSearch = async () => {
    if (!location.trim()) {
      setError('Please enter a location');
      return;
    }
  
    try {
      const res = await fetch(`/events/${encodeURIComponent(location)}`);
      const data = await res.json();
      //console.log('API Response:', data); // For debugging
  
      if (Array.isArray(data)) {
        onResults(data); 
      } else {
        onResults([data]); 
      }

      setError(null);
    } catch (err) {
      setError('The event is not present in our Database, try another city.');
    }
  };
  

  return (
    <div className="event-search">
      <input
        type="text"
        placeholder="Enter location"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>
      {error && <p className="error">{error}</p>}
    </div>
  );
}

export default SearchEvent;