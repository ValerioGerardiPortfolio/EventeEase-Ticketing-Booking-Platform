import React, { useState } from 'react';
import OpenStreet from './OpenStreet.jsx';

//function to parse date into readable date
function parseYYMMDD(raw) {
  if (typeof raw !== 'string' || raw.length !== 6) return null;

  const yy = parseInt(raw.slice(0, 2), 10);
  const mm = parseInt(raw.slice(2, 4), 10) - 1; 
  const dd = parseInt(raw.slice(4, 6), 10);
  const year = 2000 + yy;
  const dateObj = new Date(year, mm, dd);
  if (isNaN(dateObj.getTime())) return null;
  return dateObj;
}

function Event({ events, username }) {
  const [formData, setFormData] = useState({});

  const handleInputChange = (eventId, field, value) => {
    setFormData((prev) => ({
      ...prev,
      [eventId]: {
        ...prev[eventId],
        [field]: value
      }
    }));
  };

  const handleBooking = async (eventId) => {
    const eventData = formData[eventId];
    if (!eventData || !eventData.ticketType || !eventData.quantity) {
      alert('Please select both a ticket type and a quantity.');
      return;
    }

    try {
      const response = await fetch('/booktickets/booktickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          eventID: eventId,
          ticketType: eventData.ticketType,
          username: username,
          quantity: parseInt(eventData.quantity, 10)
        })
      });

      const data = await response.json();

      if (response.ok && data.success) {
        alert('Booking completed!');
        // Reset the form for this event
        setFormData((prev) => ({
          ...prev,
          [eventId]: {
            ticketType: '',
            quantity: ''
          }
        }));
      } else {
        // Show whatever message our backend returned:
        alert(data.message || 'Booking failed.');
      }
    } catch (err) {
      alert('An unexpected error occurred while booking.');
      console.error(err);
    }
  };

  if (!Array.isArray(events) || events.length === 0) {
    return <p className="no-results">No events to show.</p>;
  }

  return (
    <div className="event-results">
      {events.map((event) => {
        // Parse the raw date string
        const rawDateStr = event.date; 
        const eventDateObj = parseYYMMDD(rawDateStr);

       
        let isPast = false;
        if (eventDateObj) {
          const todayMidnight = new Date();
          todayMidnight.setHours(0, 0, 0, 0);
          isPast = eventDateObj < todayMidnight;
        }

        //Format date for display
        const displayDate = eventDateObj
          ? eventDateObj.toLocaleDateString(undefined, {
              year: 'numeric',
              month: '2-digit',
              day: '2-digit'
            })
          : rawDateStr;

        return (
          <div key={event.id} className="event-section">
            <div className="event-map">
              <OpenStreet events={[event]} username={username} />
            </div>

            <div className="event-info">
              <h2>{event.name}</h2>
              <p>
                <strong>Category:</strong> {event.category}
              </p>
              <p>
                <strong>Location:</strong> {event.location}
              </p>
              <p>
                <strong>Date:</strong> {displayDate}{' '}
                {isPast && <span style={{ color: 'red' }}>(Event expired)</span>}
              </p>
              <p>
                <strong>Description:</strong> {event.description}
              </p>

              <div className="ticket-section">
                <label htmlFor={`ticketType-${event.id}`}>
                  <strong>Ticket Type:</strong>
                </label>
                <select
                  id={`ticketType-${event.id}`}
                  value={formData[event.id]?.ticketType || ''}
                  onChange={(e) =>
                    handleInputChange(event.id, 'ticketType', e.target.value)
                  }
                  disabled={isPast}
                >
                  <option value="">-- Select Type --</option>
                  <option value="General">General</option>
                  <option value="VIP">VIP</option>
                  <option value="Student">Student</option>
                </select>

                <label htmlFor={`quantity-${event.id}`}>
                  <strong>Quantity:</strong>
                </label>
                <input
                  id={`quantity-${event.id}`}
                  type="number"
                  min="1"
                  value={formData[event.id]?.quantity || ''}
                  onChange={(e) =>
                    handleInputChange(event.id, 'quantity', e.target.value)
                  }
                  disabled={isPast}
                />

                <button
                  className="book-button"
                  onClick={() => handleBooking(event.id)}
                  disabled={isPast}
                >
                  Book Ticket
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default Event;