
import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix missing marker icons 
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png'
});

// Recenter the map when events change
function RecenterMap({ lat, lon }) {
  const map = useMap();
  map.setView([lat, lon], 13);
  return null;
}

function OpenStreet({ events, username }) {
  if (!Array.isArray(events) || events.length === 0) return null;
  const firstEvent = events[0];
  if (firstEvent.lat == null || firstEvent.lon == null) return null;

  const center = [firstEvent.lat, firstEvent.lon];

  return (
    <div
      style={{
        height: '300px',
        width: '100%',
        borderRadius: '10px',
        marginTop: '20px'
      }}
    >
      <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }}>
        {firstEvent.lat != null && firstEvent.lon != null && (
          <RecenterMap lat={firstEvent.lat} lon={firstEvent.lon} />
        )}

        <TileLayer
          attribution="&copy; OpenStreetMap contributors"
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {events.map((event) => (
          <EventMarker
            key={event.id}
            event={event}
            username={username}
          />
        ))}
      </MapContainer>
    </div>
  );
}

function EventMarker({ event, username }) {
  // Local state for ticketType/quantity inside this popup
  const [ticketType, setTicketType] = useState('');
  const [quantity, setQuantity] = useState('');

  //Feedback inside the popup
  const [feedback, setFeedback] = useState(null);
  const [loading, setLoading] = useState(false);

  // Disable booking if invalid quantity or ticketType 
  const isDisabled =
    loading ||
    ticketType.trim() === '' ||
    quantity === '' ||
    parseInt(quantity, 10) <= 0;

  // Parse event date 
  const rawDate = event.date; 
  let eventDateObj = null;
  if (typeof rawDate === 'string' && rawDate.length === 6) {
    const yy = 2000 + parseInt(rawDate.slice(0, 2), 10);
    const mm = parseInt(rawDate.slice(2, 4), 10) - 1; 
    const dd = parseInt(rawDate.slice(4, 6), 10);
    eventDateObj = new Date(yy, mm, dd);
  }

  // Check if event is in the past 
  let isPast = false;
  if (eventDateObj) {
    const todayMid = new Date();
    todayMid.setHours(0, 0, 0, 0);
    isPast = eventDateObj < todayMid;
  }

  // Format that date for display 
  const displayDate = eventDateObj
    ? eventDateObj.toLocaleDateString(undefined, {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      })
    : rawDate;

  // Submit 
  const handleSubmit = async () => {
    setLoading(true);
    setFeedback(null);
    
    try {
      const resp = await fetch('/booktickets/booktickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          eventID: event.id,
          ticketType,
          username,
          quantity: parseInt(quantity, 10)
        })
      });
      const data = await resp.json();

      if (resp.ok && data.success) {
        setFeedback({ type: 'success', message: 'Booking confirmed!' });
        setTicketType('');
        setQuantity('');
      } else {
        setFeedback({ type: 'error', message: data.message || 'Booking failed.' });
      }
    } catch (e) {
      setFeedback({ type: 'error', message: 'Server error, try again.' });
      console.error('Booking error:', e);
    }

    setLoading(false);
  };

  return (
    <Marker position={[event.lat, event.lon]}>
      <Popup minWidth={250}>
        <div style={{ maxWidth: '240px' }}>
          <h3 style={{ margin: '0 0 8px 0' }}>{event.name}</h3>
          <p style={{ margin: '0 0 8px 0' }}>{event.description}</p>
          <p style={{ margin: '0 0 8px 0' }}>
            <strong>Date:</strong> {displayDate}{' '}
            {isPast && <span style={{ color: 'red' }}>(Event Finished)</span>}
          </p>

          {isPast ? (
            <p style={{ color: '#c00', margin: '8px 0 0 0' }}>
              Sorry, the event is finished.
            </p>
          ) : (
            <>
              <label htmlFor={`popup-ticket-${event.id}`}>
                <strong>Ticket Type:</strong>
              </label>
              <select
                id={`popup-ticket-${event.id}`}
                value={ticketType}
                onChange={(e) => setTicketType(e.target.value)}
                style={{ width: '100%', margin: '4px 0 8px 0' }}
                disabled={loading}
              >
                <option value="">-- Select Type --</option>
                <option value="General">General</option>
                <option value="VIP">VIP</option>
                <option value="Student">Student</option>
              </select>

              <label htmlFor={`popup-qty-${event.id}`}>
                <strong>Quantity:</strong>
              </label>
              <input
                id={`popup-qty-${event.id}`}
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                style={{ width: '100%', margin: '4px 0 8px 0' }}
                disabled={loading}
              />

              <button
                onClick={handleSubmit}
                disabled={isDisabled}
                style={{
                  width: '100%',
                  padding: '6px 0',
                  backgroundColor: isDisabled ? '#ccc' : '#28a745',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: isDisabled ? 'not-allowed' : 'pointer'
                }}
              >
                {loading ? 'Booking…' : 'Book Now'}
              </button>

              {feedback && (
                <p
                  style={{
                    margin: '8px 0 0 0',
                    color: feedback.type === 'success' ? 'green' : 'red'
                  }}
                >
                  {feedback.message}
                </p>
              )}
            </>
          )}
        </div>
      </Popup>
    </Marker>
  );
}

export default OpenStreet;




