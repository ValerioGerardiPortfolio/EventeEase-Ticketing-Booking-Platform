EVENT EASE PROJECT
|---------------------------------------------------|
TECHNOLOGIES USED:
BACKEND:
1-NODE.JS
2-EXPRESS.JS
3-SQLITE

FRONTEND:
1-REACT
2-VITE
3-OPENSTREETMAP

UTILITIES:
1-BCRYPT (Password Hashing)

|---------------------------------------------------|


PROJECT FOLDER STRUCTURE:

root
├── back-end
│   ├── DAOs               # (Bookings, Events, Tickets, Users)
│   ├── DBConnection       # (DBCon, eventease.db)
│   ├── Middleware         # (SessionAuth)
│   ├── Routes             # (BookingsRoutes, EventRoutes, TicketsRoutes, UsersRoutes)
│   ├── Services           # (BookingsService, EventService, TicketsService, UsersService)
│   ├── Utilities          # (bcryptUtility, CreateResponse)
│   ├── Views              # (Not used for API)
│   └── index.js           # Entry point for the back-end server
├── front-end
│   ├── public             # Static resource (vite.svg)
│   └── src
│       ├── assets         # Images and icons
│       ├── components
	     # React components (Event, Login, OpenStreet, SearchEvent)
│       ├── App.jsx        # Root React Component
│       ├── main.jsx       # Application main entry point
│       └── index.css      # Global styles
├── README             	 # Project overview and setup instructions
├── package.json           # Root package manifest

|---------------------------------------------------|

PEROJECT EXECUTION

STARTING OF BACKEND SERVER IN TERMINAL:
Navigate the index.js and in the terminal type "node index"

STARTING OF FRONTEND SERVER IN TERMINAL:
Navigate the main.jsx and in the terminal type "npm run dev"
|-------------------------------------------------|
NODE PACKAGES NEED TO BE INSTALLED 